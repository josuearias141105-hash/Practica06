/* EJercicio 3 Practico: Solicite al usuario cuántos términos de la serie Fibonacci desea ver. 
Usando un bucle FOR, genere y muestre la serie. La serie comienza: 0, 1, 1, 2, 3, 5, 8, 13...*/

import readline from "node:readline";

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

rl.question("¿Cuántos términos de Fibonacci desea ver?: ", (cantidad) => {

    cantidad = Number(cantidad);

    let a = 0;
    let b = 1;

    for (let i = 1; i <= cantidad; i++) {

        console.log(a);

        let siguiente = a + b;
        a = b;
        b = siguiente;
    }

    rl.close();
});