/*Ejercicio 1 practico: Solicite un número al usuario y muestre su tabla de multiplicar
del 1 al 10 usando un bucle FOR. Formato: "5 x 1 = 5", "5 x 2 = 10", etc.*/

import readline from "node:readline";

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

rl.question("Ingrese un número: ", (numero) => {

    numero = Number(numero);

    for (let i = 1; i <= 10; i++) {
        console.log(`${numero} x ${i} = ${numero * i}`);
    }

    rl.close();
});