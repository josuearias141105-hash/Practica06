/*Ejercicio 4 practico: Solicite al usuario la cantidad de filas. 
Usando bucles FOR anidados, dibuje una pirámide de asteriscos. 
Ejemplo para 4 filas: primera fila un asterisco, segunda dos, tercera tres, cuarta cuatro..*/

import readline from "node:readline";

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

rl.question("Ingrese la cantidad de filas: ", (filas) => {

    filas = Number(filas);

    for (let i = 1; i <= filas; i++) {

        let linea = "";

        for (let j = 1; j <= i; j++) {
            linea = linea + "*";
        }

        console.log(linea);
    }

    rl.close();
});