/* Ejercicio 2 Practico: Solicite un número N. Usando un bucle FOR, recorra del 1 al N y 
calcule por separado la suma de los números pares y la suma de los impares. Muestre ambos resultados.*/

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

rl.question("Ingrese un número N: ", (N) => {

    N = Number(N);

    let sumaPares = 0;
    let sumaImpares = 0;

    for (let i = 1; i <= N; i++) {

        if (i % 2 === 0) {
            sumaPares = sumaPares + i;
        } else {
            sumaImpares = sumaImpares + i;
        }
    }

    console.log("Suma de números pares:", sumaPares);
    console.log("Suma de números impares:", sumaImpares);

    rl.close();
});